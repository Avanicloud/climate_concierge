# 🌱 Community Climate Action Concierge

An Agents for Good capstone project for Kaggle’s 5-Day AI Agents Intensive with Google. The concierge is a multi-agent system that helps neighborhood leaders design, resource, and communicate hyperlocal climate initiatives in hours instead of weeks.

---

## 🎯 Problem & Value
- **Problem**: Grassroots organizers burn time sifting through regulations, grants, and volunteer coordination tools when planning climate projects.
- **Solution**: A collaborative agent team that interviews the organizer, researches policies, assembles an action plan, surfaces funding, and drafts outreach collateral.
- **Impact**: Delivers a ready-to-run climate initiative brief with timelines, budgets, contacts, and materials—unlocking faster execution and more equitable access to expertise.

---

## 🧠 Course Concepts Demonstrated
- **Multi-agent orchestration**: Planner, Policy Researcher, Funding Scout, Communications Coach, and Evaluator roles, coordinated via an orchestration graph.
- **Tools (MCP + custom)**: Civic open-data search, grant catalog, impact simulator, timeline generator, calendar/volunteer integration stubs exposed as MCP-ready Python tools.
- **Sessions & Memory**: ADK-inspired session store for conversational context plus a JSON-backed long-term community profile.
- **Observability**: Structured logging, traces, metrics counters, and run artifact storage for reproducibility.
- **Agent evaluation**: LLM-as-judge rubric with optional human-in-the-loop feedback loop.
- **Deployment readiness**: Vertex AI Agent Engine / Cloud Run deployment guide and IaC snippets.

> Bonus-friendly features: Gemini 1.5 Flash powered sub-agents, optional deployment instructions, and a <3 min video storyboard template.

---

## 📦 Repository Layout
```
climate_concierge/
├── README.md
├── requirements.txt
├── setup.cfg
├── docs/
│   ├── architecture.md
│   ├── architecture.mmd
│   ├── evaluation_rubric.md
├── data/
│   ├── grants_catalog_sample.json
│   └── city_emissions_sample.csv
├── notebooks/
│   └── demo_run.ipynb
├── src/
│   ├── __init__.py
│   ├── config.py
│   ├── orchestrator.py
│   ├── cli.py
│   ├── agents/
│   │   ├── __init__.py
│   │   ├── base.py
│   │   ├── liaison.py
│   │   ├── policy_researcher.py
│   │   ├── funding_scout.py
│   │   ├── action_planner.py
│   │   └── comms_coach.py
│   ├── tools/
│   │   ├── __init__.py
│   │   ├── civic_data.py
│   │   ├── grant_finder.py
│   │   ├── impact_simulator.py
│   │   └── timeline_builder.py
│   ├── memory/
│   │   ├── __init__.py
│   │   ├── session_memory.py
│   │   └── long_term_memory.py
│   ├── observability/
│   │   ├── __init__.py
│   │   ├── logger.py
│   │   ├── metrics.py
│   │   └── tracer.py
│   └── evaluation/
│       ├── __init__.py
│       ├── evaluator.py
│       └── prompts.py
├── tests/
│   ├── __init__.py
│   ├── test_tools.py
│   └── test_orchestrator.py
└── submission_writeup.md
```

---

## 🚀 Quickstart
# Clone repository (if needed) and enter workspace root
git clone https://github.com/Avanicloud/climate_concierge.git
cd climate_concierge

# (Optional) create/activate virtualenv
python -m venv .venv
source .venv/bin/activate

# Install project-specific dependencies
pip install -r requirements.txt

# (Optional) export GEMINI_API_KEY before running to use live Gemini responses

# Run planning session via CLI (stub mode shown; remove flag when using Gemini)
python -m src.cli \
  --city "Oakland" \
  --state "CA" \
  --initiative "Solarize the community center roof" \
  --allow-stub-llm
```

### Notebook Demo
Open `projects/climate_concierge/notebooks/demo_run.ipynb` for an end-to-end walkthrough, including memory inspection, metrics visualization, and evaluation scoring.

---

## 🧩 Implementation Highlights
- **Modular agents**: Each agent encapsulates prompt templates, tool access, and structured payloads that flow through the orchestrator graph.
- **Tooling**: MCP-compatible wrappers enable swapping local stubs for live services (e.g., Google Search, civic APIs, Google Calendar).
- **Memory strategy**: 
  - Sessions: persisted conversation state using `InMemorySessionService`.
  - Long-term: Memory bank storing community profile, past projects, evaluation feedback, and grant outcomes.
- **Observability**:
  - JSONL logs per run in `run_artifacts/logs/`.
  - OpenTelemetry-style traces for agent hand-offs.
  - Metrics exported to Prometheus-compatible format (`run_artifacts/metrics/latest.prom`).
- **Evaluation**: Automated rubric scored by Gemini, plus CLI prompt for human feedback appended to memory.

---

## 📄 Submission Assets
- `submission_writeup.md`: polished <1500 word narrative aligned to Kaggle rubric.
- `docs/architecture.md`: includes Mermaid diagram (`architecture.mmd`), component descriptions, and deployment topology.
- `deployment/README.md`: guidance for packaging the orchestrator to Vertex AI Agent Engine or Cloud Run.

---

## ✅ Submission Checklist
1. Configure environment variables (`GEMINI_API_KEY` or `ALLOW_STUB_LLM=true`) and run `cli.py` to generate a fresh plan.
2. Export run artifacts (logs, plan JSON, evaluation scores) and attach to the README/notebook.
3. Record optional demo video following storyboard.
4. Publish repo or notebook, then complete Kaggle write-up from `submission_writeup.md`.

---

## 🧭 Roadmap & Extensions
- Integrate real-time greenhouse gas inventory APIs and utility datasets.
- Add volunteer matching integration (e.g., Mobilize, Slack) via MCP tools.
- Deploy to Vertex AI Agent Engine with scalable dispatcher and secure secrets.
- Build UI (Streamlit/Next.js) on top of REST endpoint.

---

**Built for communities that want to act on climate goals—fast, inclusive, and informed.**


