"""
Community Climate Action Concierge package.

Exports convenience functions for bootstrapping the orchestrator and CLI.
"""

from .orchestrator import ClimateConciergeOrchestrator
from .cli import main as run_cli

__all__ = ["ClimateConciergeOrchestrator", "run_cli"]

